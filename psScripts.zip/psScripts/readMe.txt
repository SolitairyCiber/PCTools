George Streeter's most excellent scripts.  
Note: 
Must be unzipped to the root of C:

========================================================
365Exchange
This is a menu with many useful 365 Powershell items.
1. List All Mailboxes
2. Get Mailbox Statistics (Size/Usage)
3. Manage Mailbox Inbox Rules
4. Manage Mailbox Permissions (Full Access)
5. Set Up Email Forwarding
6. Get Mobile Device Statistics
7. List Tenant Administrators
8. Enable SMTP Auth on Mailbox
9. Manage Calendar Sharing Permissions
10. Disconnect and Exit

I think they are all self explanatory. 
My most used ones are 4,7,and 9 
This script includes checking for the exchange modules installed and will install them if they are not present.
Run from the shortcut will also bypass the execution code restrictions and run as admin.

=======================================================

RunAsAdmin
With the need to not allow users to be local admins this is useful if you are working on their pc as them and need admin access to windows utilities.

1. Open old printers as admin
2. Open Network Adapters as admin
3. Open hosts file in notepad as admin
4. Open computer management as admin
5. Open System as admin
6. Open Device Manager as admin
7. Run System file checker as admin
8. Run DISM image health check as admin
9. Run DISM image restore health as admin
