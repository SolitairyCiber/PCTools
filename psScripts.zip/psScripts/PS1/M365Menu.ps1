# Interactive M365 Exchange Online Management Menu

# Ensure the Exchange Online module is installed
if (-not (Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
    Write-Host "ExchangeOnlineManagement module not found. Installing..." -ForegroundColor Yellow
    Install-Module -Name ExchangeOnlineManagement -Force -AllowClobber -Scope CurrentUser
}

# Ensure Microsoft Graph module is installed for fetching tenant directory roles
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Beta)) {
    Write-Host "Microsoft.Graph.Beta module not found. Installing..." -ForegroundColor Yellow
    Install-Module -Name Microsoft.Graph.Beta -Force -AllowClobber -Scope CurrentUser
}

# Connect to Exchange Online and Microsoft Graph
Write-Host "Connecting to Exchange Online..." -ForegroundColor Cyan
Connect-ExchangeOnline

Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan
Connect-MgGraph -Scopes "RoleManagement.Read.Directory", "Directory.Read.All"

function Show-Menu {
    Clear-Host
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "   M365 EXCHANGE ONLINE MANAGEMENT MENU      " -ForegroundColor Cyan
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "1. List All Mailboxes"
    Write-Host "2. Get Mailbox Statistics (Size/Usage)"
    Write-Host "3. Manage Mailbox Inbox Rules"
    Write-Host "4. Manage Mailbox Permissions (Full Access)"
    Write-Host "5. Set Up Email Forwarding"
    Write-Host "6. Get Mobile Device Statistics"
    Write-Host "7. List Tenant Administrators"
    Write-Host "8. Enable SMTP Auth on Mailbox"
    Write-Host "9. Manage Calendar Sharing Permissions"
    Write-Host "10. Disconnect and Exit"
    Write-Host "=============================================" -ForegroundColor Cyan
}

do {
    Show-Menu
    \$choice = Read-Host "Please select an option (1-10)"

    switch (\$choice) {
        '1' {
            Clear-Host
            Write-Host "--- All Mailboxes ---" -ForegroundColor Green
            Get-Mailbox -ResultSize Unlimited | Select-Object DisplayName, UserPrincipalName, PrimarySmtpAddress | Format-Table -AutoSize
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '2' {
            Clear-Host
            Write-Host "--- Mailbox Statistics ---" -ForegroundColor Green
            \$upn = Read-Host "Enter the User Principal Name (UPN) or Email"
            Get-MailboxStatistics -Identity \$upn | Select-Object DisplayName, TotalItemSize, ItemCount | Format-Table -AutoSize
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '3' {
            Clear-Host
            Write-Host "--- Mailbox Inbox Rules ---" -ForegroundColor Green
            \$upn = Read-Host "Enter the User Principal Name (UPN) or Email"
            Get-InboxRule -Mailbox \$upn | Select-Object Name, Enabled, RedirectTo, ForwardTo | Format-Table -AutoSize
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '4' {
            Clear-Host
            Write-Host "--- Mailbox Permissions (Full Access) ---" -ForegroundColor Green
            \$upn = Read-Host "Enter the User Principal Name (UPN) or Email"
            Get-MailboxPermission -Identity upn | Where-Object _.User -notlike "NT AUTHORITY\*" -and \$_.AccessRights -contains "FullAccess" } | Select-Object User, AccessRights | Format-Table -AutoSize
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '5' {
            Clear-Host
            Write-Host "--- Set Up Email Forwarding ---" -ForegroundColor Green
            \$upn = Read-Host "Enter the User Principal Name (UPN)"
            \$forwardTo = Read-Host "Enter the target forwarding email address"
            Set-Mailbox -Identity \$upn -ForwardingSmtpAddress forwardTo -DeliverToMailboxAndForward true
            Write-Host "Forwarding successfully configured." -ForegroundColor Green
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '6' {
            Clear-Host
            Write-Host "--- Mobile Device Statistics ---" -ForegroundColor Green
            \$upn = Read-Host "Enter the User Principal Name (UPN) or Email"
            Get-MobileDeviceStatistics -Mailbox \$upn | Select-Object DeviceOS, DeviceModel, LastSuccessSync | Format-Table -AutoSize
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '7' {
            Clear-Host
            Write-Host "--- Tenant Administrators ---" -ForegroundColor Green
            
            \$roles = Get-MgBetaDirectoryRole
            foreach (role in roles) {
                members = Get-MgBetaDirectoryRoleMember -DirectoryRoleId role.Id
                if (\$members) {
                    Write-Host "`nRole: $($role.DisplayName)" -ForegroundColor Yellow
                    foreach ($member in $members) {
                        $userDetail = Get-MgBetaUser -UserId $member.Id
                        Write-Host "  - $($userDetail.DisplayName) ($($userDetail.UserPrincipalName))"
                    }
                }
            }
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '8' {
            Clear-Host
            Write-Host "--- Enable SMTP Auth ---" -ForegroundColor Green
            $upn = Read-Host "Enter the User Principal Name (UPN) or Email"
            
            $currentStatus = Get-CASMailbox -Identity $upn | Select-Object -ExpandProperty SmtpClientAuthenticationDisabled
            
            if ($currentStatus -eq $false) {
                Write-Host "SMTP Auth is already ENABLED for this user." -ForegroundColor Yellow
            } else {
                Write-Host "Current Status: Disabled (or relying on tenant defaults)." -ForegroundColor Yellow
                Write-Host "Enabling SMTP Auth..." -ForegroundColor Cyan
                Set-CASMailbox -Identity $upn -SmtpClientAuthenticationDisabled $false
                Write-Host "SMTP Auth has been successfully enabled for $upn." -ForegroundColor Green
            }
            Write-Host ""
            Read-Host "Press Enter to return to the menu"
        }
        '9' {
            Clear-Host
            Write-Host "--- Manage Calendar Sharing Permissions ---" -ForegroundColor Green
            $targetMailbox = Read-Host "Enter the Mailbox UPN whose calendar you want to manage"
            
            # Formulate identity string assuming default US/UK location folder name (:\Calendar)
            # Adjust the text if regional settings are localized differently (e.g., :\Kalender)
            $calendarIdentity = "$targetMailbox:\Calendar"
            
            Write-Host "`n1. View Current Calendar Permissions"
            Write-Host "2. Add or Update a User's Permission"
            Write-Host "3. Remove a User's Permission"
            \$calChoice = Read-Host "Select an action (1-3)"
            
            switch (\$calChoice) {
                '1' {
                    Clear-Host
                    Write-Host "--- Current Calendar Permissions for \$targetMailbox ---" -ForegroundColor Cyan
                    Get-MailboxFolderPermission -Identity \$calendarIdentity | Select-Object User, AccessRights | Format-Table -AutoSize
                }
                '2' {
                    \$shareWith = Read-Host "Enter the UPN of the user/group to grant access to"
                    Write-Host "Available Roles: Owner, Editor, Reviewer, AvailabilityOnly, LimitedDetails" -ForegroundColor Gray
                    \$role = Read-Host "Enter the desired Access Right Role"
                    
                    try {
                        # Attempt to add new permission block
                        Write-Host "Attempting to add permission..." -ForegroundColor Cyan
                        Add-MailboxFolderPermission -Identity \$calendarIdentity -User shareWith -AccessRights role -ErrorAction Stop
                        Write-Host "Successfully assigned role role to shareWith." -ForegroundColor Green
                    } catch {
                        # If relationship already exists, use Set cmdlet to overwrite instead
                        Write-Host "User entry may already exist. Attempting update instead..." -ForegroundColor Yellow
                        Set-MailboxFolderPermission -Identity \$calendarIdentity -User shareWith -AccessRights role -ErrorAction SilentlyContinue
                        Write-Host "Successfully updated shareWith to role role." -ForegroundColor Green
                    }
                }
                '3' {
                    \$removeUser = Read-Host "Enter the UPN of the user/group to remove"
                    Remove-MailboxFolderPermission -Identity \$calendarIdentity -User removeUser -Confirm:false
                    Write-Host "Successfully removed calendar permissions for \$removeUser." -ForegroundColor Green
                }
                Default {
                    Write-Host "Invalid sub-selection." -ForegroundColor Red
                }
            }
            Write-Host ""
            Read-Host "Press Enter to return to the main menu"
        }
        '10' {
            Clear-Host
            Write-Host "Disconnecting sessions..." -ForegroundColor Yellow
            Disconnect-ExchangeOnline -Confirm:\$false
            Disconnect-MgGraph
            Write-Host "Goodbye!" -ForegroundColor Green
            break
        }
        Default {
            Write-Host "Invalid selection. Please try again." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
} while (\$choice -ne '10')
