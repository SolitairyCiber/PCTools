# Script by George Streeter CRT
# Interactive Admin Tools Quick-Launcher

# Ensure gsudo is installed via winget
if (-not (Get-Command gsudo -ErrorAction SilentlyContinue)) {
    Write-Host "gsudo not found. Installing via winget..." -ForegroundColor Yellow
    winget install gerardog.gsudo --silent --accept-source-agreements --accept-package-agreements
    # Refresh environment path for the current session so gsudo works immediately
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}

function Show-Menu {
    Clear-Host
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "       ADMIN TOOLS QUICK-LAUNCHER            " -ForegroundColor Cyan
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "1. Open old printers as admin"
    Write-Host "2. Open Network Adapters as admin"
    Write-Host "3. Open hosts file in notepad as admin"
    Write-Host "4. Open computer management as admin"
    Write-Host "5. Open System properties as admin"
    Write-Host "6. Open Device Manager as admin"
    Write-Host "7. Run System file checker (SFC)"
    Write-Host "8. Run DISM image health check"
    Write-Host "9. Run DISM image restore health"
    Write-Host "10. Exit"
    Write-Host "=============================================" -ForegroundColor Cyan
}

do {
    Show-Menu
    $Item = Read-Host "Pick a number and press Enter (1-10)"

    switch ($Item) {
        '1' {
            Clear-Host
            Write-Host "Opening Devices and Printers as admin..." -ForegroundColor Green
            gsudo explorer.exe "shell:::{A8A91A66-3A7D-4424-8D24-04E180695C7A}"
            Start-Sleep -Seconds 1
        }
        '2' {
            Clear-Host
            Write-Host "Opening Network Connections as admin..." -ForegroundColor Green
            gsudo control ncpa.cpl
            Start-Sleep -Seconds 1
        }
        '3' {
            Clear-Host
            Write-Host "Opening hosts file in Notepad as admin..." -ForegroundColor Green
            gsudo notepad.exe "C:\Windows\System32\drivers\etc\hosts"
            Start-Sleep -Seconds 1
        }
        '4' {
            Clear-Host
            Write-Host "Opening Computer Management as admin..." -ForegroundColor Green
            gsudo mmc compmgmt.msc
            Start-Sleep -Seconds 1
        }
        '5' {
            Clear-Host
            Write-Host "Opening System Properties as admin..." -ForegroundColor Green
            gsudo control sysdm.cpl
            Start-Sleep -Seconds 1
        }
        '6' {
            Clear-Host
            Write-Host "Opening Device Manager as admin..." -ForegroundColor Green
            gsudo mmc devmgmt.msc
            Start-Sleep -Seconds 1
        }
        '7' {
            Clear-Host
            Write-Host "Running System File Checker..." -ForegroundColor Green
            gsudo sfc /scannow
            Write-Host ""
            Read-Host "Press Enter to return to menu"
        }
        '8' {
            Clear-Host
            Write-Host "Running DISM ScanHealth..." -ForegroundColor Green
            gsudo DISM /Online /Cleanup-Image /ScanHealth
            Write-Host ""
            Read-Host "Press Enter to return to menu"
        }
        '9' {
            Clear-Host
            Write-Host "Running DISM RestoreHealth..." -ForegroundColor Green
            gsudo DISM /Online /Cleanup-Image /RestoreHealth
            Write-Host ""
            Read-Host "Press Enter to return to menu"
        }
        '10' {
            Clear-Host
            Write-Host "Exiting. Goodbye!" -ForegroundColor Green
            break
        }
        Default {
            Write-Host "Invalid selection. Please try again." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
} while ($Item -ne '10')






